from django.views.generic import TemplateView
from django.shortcuts import render 
from django.contrib.auth import authenticate, login, logout
from .forms import SingupForm, LoginForm

class IndexPageView(TemplateView):
    template_name = 'main/home1.html'

def page_view(request):
    return render(request, 'layouts/default/page.html')

class ChangeLanguageView(TemplateView):
    template_name = 'main/change_language.html'

#signup
def user_signup(request):
    if request.method == "POST":
        form = SingupForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
        else:
            form = SingupForm()
        return render(request, 'signup.html', {'form': form})

#login page
def user_login(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            user = authenticate(request, email = email, password = password)
            if user:
                login(request, user)
                return redirect('home1')
        else:
            form = LoginForm()
            # \source\accounts\templates\accounts\log_in.html
        return render(request, 'source/accounts/templates/accounts/log_in.html', {'form' : form})

# logout page
def user_logout(request):
    logout(request)
    return redirect('login')